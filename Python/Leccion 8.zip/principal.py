class Persona:
    def __init__(self, nombre, edad):
        self._nombre = nombre   # atributo privado
        self._edad = edad       # atributo privado

    # Getter para nombre
    def get_nombre(self):
        return self._nombre

    # Setter para nombre
    def set_nombre(self, nuevo_nombre):
        self._nombre = nuevo_nombre

    # Getter para edad
    def get_edad(self):
        return self._edad

    # Setter para edad
    def set_edad(self, nueva_edad):
        if nueva_edad >= 0:
            self._edad = nueva_edad
        else:
            print("La edad no puede ser negativa.")

    # Método para mostrar los detalles
    def mostrar_detalles(self):
        print(f"Nombre: {self._nombre}, Edad: {self._edad}")


# Crear tres objetos
persona1 = Persona("Ana", 25)
persona2 = Persona("Luis", 30)
persona3 = Persona("Carla", 22)

# Mostrar detalles iniciales
print("Detalles iniciales:")
persona1.mostrar_detalles()
persona2.mostrar_detalles()
persona3.mostrar_detalles()

# Modificar usando setters
persona1.set_nombre("Ana María")
persona1.set_edad(26)

persona2.set_nombre("Luis Alberto")
persona2.set_edad(31)

persona3.set_nombre("Carla Sofía")
persona3.set_edad(23)

# Mostrar detalles después de modificar
print("\nDetalles después de modificaciones:")
persona1.mostrar_detalles()
persona2.mostrar_detalles()
persona3.mostrar_detalles()